"""
cycle_certificate.py
--------------------
Non-triviality certificate for scaffold cycles, following the delta-homology note.

A cycle is *trivial* if its homology class is zero in H1 = ker d1 / im d2 -- i.e. it
is a boundary, a loop "filled" by a 2-cell, homologically reducible and condensed away.
It is *non-trivial* if its class is a nonzero GENERATOR of H1: irreducible (not a sum of
boundaries) and PERSISTENT across the filtration (lifetime above threshold). Only
non-trivial cycles qualify as stable scaffolds and survive topological condensation
(deformation of the cycle to a point one rung up the Urysohn ladder).

We work over Z_2. The certificate has two layers, exactly as in the note:
  (1) homological:  beta_1 = dim ker d1 - rank d2  (number of non-boundary cycle classes)
  (2) persistence:  a cycle's lifetime = (death scale - birth scale) over a filtration;
                    non-trivial <=> lifetime > tau_persist.
"""
import numpy as np
import itertools


# ----------------------------------------------------------------------
# Z_2 linear algebra (Gaussian elimination over GF(2))
# ----------------------------------------------------------------------
def gf2_rank(M):
    """Rank of a 0/1 matrix over GF(2)."""
    if M.size == 0:
        return 0
    A = (np.asarray(M) % 2).astype(np.uint8).copy()
    rows, cols = A.shape
    r = 0
    for c in range(cols):
        piv = None
        for i in range(r, rows):
            if A[i, c]:
                piv = i
                break
        if piv is None:
            continue
        A[[r, piv]] = A[[piv, r]]
        for i in range(rows):
            if i != r and A[i, c]:
                A[i] ^= A[r]
        r += 1
        if r == rows:
            break
    return r


# ----------------------------------------------------------------------
# Build a simplicial complex on chart nodes from a similarity graph.
#   - 0-cells: charts
#   - 1-cells: edges between charts whose similarity >= birth scale (filtration)
#   - 2-cells: triangles whose three edges are all present (these FILL loops)
# A loop that becomes the boundary of present 2-cells is TRIVIAL.
# ----------------------------------------------------------------------
def edges_at_scale(S, scale):
    """Edges (i<j) with similarity S[i,j] >= scale."""
    n = S.shape[0]
    E = [(i, j) for i in range(n) for j in range(i + 1, n) if S[i, j] >= scale]
    return E


def triangles_at_scale(S, scale):
    """Triangles (i<j<k) whose 3 edges are all >= scale (clique-filled => fillable)."""
    n = S.shape[0]
    T = []
    for i, j, k in itertools.combinations(range(n), 3):
        if S[i, j] >= scale and S[i, k] >= scale and S[j, k] >= scale:
            T.append((i, j, k))
    return T


def boundary_matrices(n, E, T):
    """d1: edges->vertices (n x |E|); d2: triangles->edges (|E| x |T|), over Z_2."""
    eidx = {e: m for m, e in enumerate(E)}
    d1 = np.zeros((n, len(E)), dtype=np.uint8)
    for m, (i, j) in enumerate(E):
        d1[i, m] ^= 1
        d1[j, m] ^= 1
    d2 = np.zeros((len(E), len(T)), dtype=np.uint8)
    for t, (i, j, k) in enumerate(T):
        for e in [(i, j), (i, k), (j, k)]:
            d2[eidx[e], t] ^= 1
    return d1, d2


def betti1(S, scale):
    """beta_1 of the clique-ish complex at a given similarity scale."""
    n = S.shape[0]
    E = edges_at_scale(S, scale)
    T = triangles_at_scale(S, scale)
    if len(E) == 0:
        return 0
    d1, d2 = boundary_matrices(n, E, T)
    dim_Z1 = len(E) - gf2_rank(d1)        # dim ker d1
    rank_B1 = gf2_rank(d2)                # dim im d2
    return dim_Z1 - rank_B1               # beta_1 = generators of H1


# ----------------------------------------------------------------------
# Persistence of H1 over a DESCENDING similarity filtration.
# As 'scale' decreases, more edges appear (loops are BORN); then triangles
# appear and FILL them (loops DIE). Lifetime = birth_scale - death_scale.
# A non-trivial scaffold cycle is one with lifetime > tau_persist.
# ----------------------------------------------------------------------
def betti1_curve(S, scales):
    return np.array([betti1(S, s) for s in scales])


def h1_persistence(S, scales):
    """
    Return (peak_beta1, total_persistence, per_scale_beta1).
    'total_persistence' integrates beta_1 over the (descending) scale axis: long-lived
    generators contribute large area; transient (immediately-filled) loops contribute ~0.
    """
    scales = np.asarray(scales, dtype=float)
    b = betti1_curve(S, scales)
    # width of each scale bin (descending) for a crude lifetime integral
    if len(scales) > 1:
        dscale = np.abs(np.gradient(scales))
    else:
        dscale = np.ones_like(scales)
    total_persistence = float(np.sum(b * dscale))
    return int(b.max()) if len(b) else 0, total_persistence, b


def certify_scaffold(S, scales, tau_persist):
    """
    Count NON-TRIVIAL scaffold cycles = the PERSISTENT first Betti number, read as the
    beta_1 level that is held over the widest contiguous band of the filtration (its
    persistence plateau). Transient loops -- born and immediately filled (trivial), or
    spurious low-scale cross-links -- occupy only thin bands and are rejected. The
    plateau level is the robust generator count; the peak (max over all scales) includes
    those transients.
    """
    peak, total, curve = h1_persistence(S, scales)
    curve = np.asarray(curve)
    n = len(curve)
    if n == 0:
        return dict(peak_beta1=0, persistent_beta1=0, total_persistence=0.0, curve=curve)
    # For each level L, the longest contiguous run with beta_1 == L (its plateau width).
    best_level, best_width = 0, -1
    for L in range(0, peak + 1):
        run = mx = 0
        for v in curve:
            if v == L:
                run += 1; mx = max(mx, run)
            else:
                run = 0
        if L >= 1 and mx / n >= tau_persist and mx > best_width:
            best_width, best_level = mx, L
    return dict(peak_beta1=peak, persistent_beta1=best_level,
                total_persistence=total, curve=curve)


# ----------------------------------------------------------------------
# Condensation along the Urysohn ladder: contract each non-trivial cycle to a
# single node of the next level. Operationally: cluster the charts of the current
# level into super-nodes (one per persistent generator's support), and return the
# super-node similarity matrix -- the next rung's complex.
# ----------------------------------------------------------------------
def condense(S, labels):
    """
    labels[i] = super-node id of chart i (the cycle/component it condensed into).
    Returns the super-node similarity matrix (mean inter-group similarity), i.e. the
    'dot of the next level' representation on which the ladder step is re-run.
    """
    groups = sorted(set(labels))
    g2i = {g: i for i, g in enumerate(groups)}
    m = len(groups)
    Snext = np.zeros((m, m))
    cnt = np.zeros((m, m))
    n = S.shape[0]
    for i in range(n):
        for j in range(n):
            a, b = g2i[labels[i]], g2i[labels[j]]
            Snext[a, b] += S[i, j]
            cnt[a, b] += 1
    cnt[cnt == 0] = 1
    Snext = Snext / cnt
    np.fill_diagonal(Snext, 1.0)
    return Snext, groups
